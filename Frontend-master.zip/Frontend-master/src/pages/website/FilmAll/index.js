import { Box } from "@chakra-ui/react";
import React from "react";
import FilmInfo from "../../../components/website/FilmInfo";


const FilmAll = () => {
    return(
        <Box>
           <FilmInfo/>
        </Box>
    )
}

export default FilmAll
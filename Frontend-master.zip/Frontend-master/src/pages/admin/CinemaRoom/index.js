import React from 'react';
import ShowDataCinemaRoom from '../../../components/admin/ShowDataCinemaRoom';

function CinemaRoom() {
        return (
           <ShowDataCinemaRoom />
        )
}


export default CinemaRoom
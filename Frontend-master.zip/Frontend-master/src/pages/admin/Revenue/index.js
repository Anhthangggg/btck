import React from 'react';
import ShowDataRevenue from '../../../components/admin/ShowDataRevenue';

function Revenue() {
        return (
           <ShowDataRevenue/>
        )
}


export default Revenue;
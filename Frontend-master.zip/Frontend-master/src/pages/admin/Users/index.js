import React from 'react';
import ShowDataUsers from '../../../components/admin/ShowDataUsers';

function Users() {
        return (
            <ShowDataUsers/>
        );
}


export default Users;
import React from 'react';
import ShowDataPopcorn from '../../../components/admin/ShowDataPopcorn';

function Popcorn() {
        return (
           <ShowDataPopcorn/>
        )
}


export default Popcorn;
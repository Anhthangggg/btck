import React from 'react';
import ShowDataShowtime from '../../../components/admin/ShowDataShowtime';

function Showtime() {
        return (
           <ShowDataShowtime/>
        )
}


export default Showtime;